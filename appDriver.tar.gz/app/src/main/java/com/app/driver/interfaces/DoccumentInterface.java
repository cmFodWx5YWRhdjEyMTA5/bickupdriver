package com.app.driver.interfaces;

import android.support.v4.app.Fragment;

/**
 * Created by root on 5/11/17.
 */

public interface DoccumentInterface {

    public  void callFragment(Fragment fragment);
}
