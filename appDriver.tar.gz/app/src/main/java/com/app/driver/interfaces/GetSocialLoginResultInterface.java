package com.app.driver.interfaces;

import com.app.driver.model.User;

/**
 * Created by fluper-pc on 18/9/17.
 */

public interface GetSocialLoginResultInterface {
    public void getLoginresult(User mUser);
}
