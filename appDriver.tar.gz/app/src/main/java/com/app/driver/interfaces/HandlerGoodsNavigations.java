package com.app.driver.interfaces;

/**
 * Created by fluper-pc on 28/9/17.
 */

public interface HandlerGoodsNavigations {

    public void callBookingDetailsFragment();
    public void callGoodsFragment();
    public void callTrackDriverActivity();

}
