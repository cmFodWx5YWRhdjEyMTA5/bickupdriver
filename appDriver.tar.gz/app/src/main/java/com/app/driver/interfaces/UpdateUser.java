package com.app.driver.interfaces;

/**
 * Created by root on 6/11/17.
 */

public interface UpdateUser {
    public void updateUser();
}
