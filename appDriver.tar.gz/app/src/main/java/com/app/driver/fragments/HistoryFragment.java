package com.app.driver.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.app.driver.R;
import com.app.driver.adapter.BookingsAdapter;


public class HistoryFragment extends Fragment {
    Activity activity;
    ListView listView;
    private String[] array={"Single Bed","Refrigerator","Single Bed"};



    public HistoryFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_history, container, false);
        listView=(ListView)view.findViewById(R.id.delivery_history);
        listView.setAdapter(new BookingsAdapter(activity,array,1));
        return view;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity=activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


}
