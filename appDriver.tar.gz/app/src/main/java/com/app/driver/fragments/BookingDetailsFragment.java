package com.app.driver.fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.app.driver.GoodsActivity;
import com.app.driver.R;
import com.app.driver.TrackDriverActivity;
import com.app.driver.interfaces.HandlerGoodsNavigations;
import com.app.driver.utility.ConstantValues;


public class BookingDetailsFragment extends Fragment implements View.OnClickListener {


    public static String Tag=BookingDetailsFragment.class.getSimpleName();
    private Typeface  mTypefaceRegular;
    private Typeface  mTypefaceBold;
    private GoodsActivity mActivityReference;
    private TextView    btnAccept,btnReject;


    private TextView  labelBookingDate;
    private TextView  labelBookingTime;
    private TextView  labelHelper;
    private TextView  lebalAmount;
    private TextView  valuePrice;
    private TextView  valueHelperPrice;
    private TextView  labelHelperPrice;
    private TextView  valueTotalPrice;
    private TextView    txtContact;
    private TextView    txtTypesGoods;

    private TextView valueBookingDate;
    private TextView valueBookingTime;

    public BookingDetailsFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_booking_detail, container, false);
        initializeViews(view);
        return view;
    }

    private void initializeViews(View view) {

        mTypefaceRegular= Typeface.createFromAsset(mActivityReference.getAssets(), ConstantValues.TYPEFACE_REGULAR);
        mTypefaceBold=Typeface.createFromAsset(mActivityReference.getAssets(), ConstantValues.TYPEFACE_BOLD);
        labelBookingDate=(TextView)view.findViewById(R.id.txt_header_otp);
        labelBookingDate=(TextView)view.findViewById(R.id.label_booking_date);
        labelBookingTime=(TextView)view.findViewById(R.id.label_booking_time);
        labelHelper=(TextView)view.findViewById(R.id.label_helper);
        valueBookingDate=(TextView)view.findViewById(R.id.value_booking_date);
        valueBookingTime =(TextView)view.findViewById(R.id.value_booking_time);
        labelHelperPrice=(TextView)view.findViewById(R.id.label_helper_price);


        lebalAmount=(TextView)view.findViewById(R.id.label_amount);
        valuePrice =(TextView)view.findViewById(R.id.value_price);
        valueHelperPrice=(TextView)view.findViewById(R.id.value_helper_price);
        valueTotalPrice=(TextView)view.findViewById(R.id.value_total_price);
        txtContact=(TextView)view.findViewById(R.id.label_contact_details);
        txtTypesGoods=(TextView)view.findViewById(R.id.label_types_goods);


        btnAccept=(TextView) view.findViewById(R.id.btn_accept);
        btnReject=(TextView)view.findViewById(R.id.btn_reject);
        btnReject.setOnClickListener(this);
        btnAccept.setOnClickListener(this);

        btnReject.setTypeface(mTypefaceRegular);
        btnReject.setTypeface(mTypefaceRegular);

        lebalAmount.setTypeface(mTypefaceRegular);
        valuePrice.setTypeface(mTypefaceRegular);
        valueHelperPrice.setTypeface(mTypefaceRegular);
        valueTotalPrice.setTypeface(mTypefaceBold);
        labelBookingDate.setTypeface(mTypefaceRegular);
        labelBookingTime.setTypeface(mTypefaceRegular);
        labelHelper.setTypeface(mTypefaceRegular);
        valueBookingDate.setTypeface(mTypefaceRegular);
        valueBookingTime.setTypeface(mTypefaceRegular);
        labelHelperPrice.setTypeface(mTypefaceRegular);
        txtContact.setTypeface(mTypefaceRegular);
        txtTypesGoods.setTypeface(mTypefaceRegular);
    }




   /* private boolean validateFields() {
        if(!CommonMethods.getInstance().validateEditFeild(edtContactName.getText().toString())){
            Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_contact_person_name), Toast.LENGTH_SHORT).show();
            return false;
        }


        if(!CommonMethods.getInstance().validateEditFeild(edtContactNumber.getText().toString())){
            Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_vaidate_mobile), Toast.LENGTH_SHORT).show();
            return false;
        }else{
            if(!CommonMethods.getInstance().validateMobileNumber(edtContactNumber.getText().toString(),6)){
                Toast.makeText(mActivityReference, mActivityReference.getResources().getString(R.string.txt_vaidate_mobile_number), Toast.LENGTH_SHORT).show();
                return false;
            }

        }
        return true;
    }*/

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivityReference=(GoodsActivity)context;

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    private void showPopUp() {
        final Dialog openDialog = new Dialog(mActivityReference);
        openDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        openDialog.setContentView(R.layout.booking_confirmation_dialog);
        openDialog.setTitle("Custom Dialog Box");
        openDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
      /*  TextView travellerName = (TextView)openDialog.findViewById(R.id.txt_traveller_name_dialog);

        TextView travellerCost = (TextView)openDialog.findViewById(R.id.txt_traveller_cost);
        ImageView travellerImage = (ImageView)openDialog.findViewById(R.id.img_traveller);
        Button btnDone = (Button)openDialog.findViewById(R.id.btn_done);
*/
        Button btnAgree = (Button)openDialog.findViewById(R.id.btn_done);
      /*  travellerName.setTypeface(mTypefaceBold);
        travellerCost.setTypeface(mTypefaceRegular);
        btnDisagree.setTypeface(mTypefaceBold);*/
//        btnAgree.setTypeface(mTypefaceBold);

        btnAgree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openDialog.dismiss();
                Intent intent=new Intent(mActivityReference,TrackDriverActivity.class);
                startActivity(intent);
            }
        });
      /*  btnAgree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                openDialog.dismiss();
                Intent intent=new Intent(MainActivity.this,GoodsActivity.class);
                startActivity(intent);
            }
        });*/
        openDialog.show();

    }
    @Override
    public void onClick(View view) {
        HandlerGoodsNavigations handlerGoodsNavigations=mActivityReference;
        int id=view.getId();
        switch (id){
            case R.id.btn_confirm_booking:
              /*  if(validateFields()){
                    showPopUp();
                }*/
                break;
            case R.id.btn_accept:
                mActivityReference.finish();

                break;
            case R.id.btn_reject:
                mActivityReference.finish();
                break;

        }
    }
}
