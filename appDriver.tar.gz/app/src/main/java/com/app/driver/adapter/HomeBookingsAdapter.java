package com.app.driver.adapter;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.driver.GoodsActivity;
import com.app.driver.R;


/**
 * Created by fluper-pc on 25/10/17.
 */

public class HomeBookingsAdapter extends RecyclerView.Adapter<HomeBookingsAdapter.MyViewHolder>  {

    private Activity activity;
    private String[] array;
    public HomeBookingsAdapter(Activity activity,String[] array){
        this.activity=activity;
        this.array=array;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView txtOngoing;
        private RelativeLayout rlcontainer;

        public MyViewHolder(View view) {
            super(view);
            rlcontainer=(RelativeLayout)view.findViewById(R.id.content_container);
            txtOngoing=(TextView)view.findViewById(R.id.txt_ongoing);


        }
    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_bookings, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        if(position==0){
            holder.txtOngoing.setText(activity.getString(R.string.txt_ongoing));
        }else {
            holder.txtOngoing.setText(activity.getString(R.string.txt_waiting));

        }
            holder.rlcontainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(activity,GoodsActivity.class);
                   activity.startActivity(intent);
                }
            });
    }


    @Override
    public int getItemCount() {
        return array.length;
    }
}
