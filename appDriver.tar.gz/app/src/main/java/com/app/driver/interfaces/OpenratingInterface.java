package com.app.driver.interfaces;

/**
 * Created by fluper-pc on 11/10/17.
 */

public interface OpenratingInterface  {
    public void openDialog();
}
