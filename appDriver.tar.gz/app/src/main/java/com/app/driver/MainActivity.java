package com.app.driver;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.driver.adapter.HomeBookingsAdapter;
import com.app.driver.broadcastreciever.InternetConnectionBroadcast;
import com.app.driver.controller.AppController;
import com.app.driver.model.User;
import com.app.driver.utility.CMSActivity;
import com.app.driver.utility.CommonMethods;
import com.app.driver.utility.ConstantValues;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.koushikdutta.ion.Ion;

import nl.psdcompany.duonavigationdrawer.views.DuoDrawerLayout;

import static com.app.driver.utility.ConstantValues.KEY_CAMERA_POSITION;
import static com.app.driver.utility.ConstantValues.KEY_LOCATION;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, InternetConnectionBroadcast.ConnectivityRecieverListener, OnMapReadyCallback, View.OnClickListener {

    private Snackbar snackbar;

    public static String TAG = MainActivity.class.getSimpleName();
    private boolean mIsConnected;
    private Activity mActivityreference;
    private Location mCurrentLocation;
    private boolean mLocationPermission = false;
    private LocationManager mLocationmanager;
    private LocationListener mLocationListener;
    private GoogleMap googleMap;

    private CameraPosition mCameraPosition;

    private Button btnStartLoading;
    private Typeface mTypefaceRegular;
    private Typeface mTypefaceBold;
    private DuoDrawerLayout drawerLayout;
    private ImageView navigationDrawer;

    private RecyclerView recyclerViewBookings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // overridePendingTransition(R.anim.slide_in, R.anim._slide_out);
        setContentView(R.layout.activity_main);
        mActivityreference = MainActivity.this;
        intializeViews();
       // setLayoutForSmallTraveller();
        initializeForLocation(savedInstanceState);
        setGoogleMap();
       // CheckdrawerLayout.openDrawer(Gravity.RIGHT);
    }

    private void initializeForLocation(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            mCurrentLocation = savedInstanceState.getParcelable(KEY_LOCATION);
            mCameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION);
        }
        mLocationmanager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        mLocationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                mCurrentLocation = location;
              // updateLocationUI();
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return false;
    }

    private void getUserCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mLocationPermission = true;
            mCurrentLocation=mLocationmanager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            mLocationmanager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mLocationListener);
            updateLocationUI();
            return;
        }

    }

    private void setGoogleMap() {
        SupportMapFragment mAupportMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mAupportMapFragment.getMapAsync(this);

    }

    private void intializeViews() {
        TextView labelJobProvided,labelRevenue,valueJobProvided,valueRevenue,txtOnline,valueBookingPovided;
        mTypefaceRegular= Typeface.createFromAsset(getAssets(), ConstantValues.TYPEFACE_REGULAR);
        mTypefaceBold=Typeface.createFromAsset(getAssets(), ConstantValues.TYPEFACE_BOLD);
        recyclerViewBookings=(RecyclerView)findViewById(R.id.ry_bookings);
        setBookingList();
        labelJobProvided=(TextView)findViewById(R.id.label_job_provided);
        valueJobProvided=(TextView)findViewById(R.id.value_job_provided);
        valueBookingPovided=(TextView)findViewById(R.id.value_booking_provided);
        labelRevenue=(TextView)findViewById(R.id.label_revenue);
        valueRevenue=(TextView)findViewById(R.id.value_revenue);
        txtOnline=(TextView)findViewById(R.id.txt_online);
        labelJobProvided.setTypeface(mTypefaceRegular);
        valueJobProvided.setTypeface(mTypefaceBold);
        labelRevenue.setTypeface(mTypefaceRegular);
        valueRevenue.setTypeface(mTypefaceBold);
        valueBookingPovided.setTypeface(mTypefaceBold);
        txtOnline.setTypeface(mTypefaceRegular);

        btnStartLoading=(Button)findViewById(R.id.btn_start_loading);
        btnStartLoading.setOnClickListener(this);
        btnStartLoading.setTypeface(mTypefaceRegular);
        navigationDrawer=(ImageView)findViewById(R.id.navigation_menu);
        navigationDrawer.setOnClickListener(this);


        findViewById(R.id.box_container).setOnClickListener(this);
        findViewById(R.id.bookingtxt_container).setOnClickListener(this);
        findViewById(R.id.menu_delivery).setOnClickListener(this);
    //    findViewById(R.id.menu_scheduled).setOnClickListener(this);
        findViewById(R.id.menu_setting).setOnClickListener(this);
        findViewById(R.id.userimage).setOnClickListener(this);
        findViewById(R.id.revenue_container).setOnClickListener(this);
        findViewById(R.id.contactus_container).setOnClickListener(this);
        findViewById(R.id.aboutus_container).setOnClickListener(this);
        findViewById(R.id.privacy_container).setOnClickListener(this);
        findViewById(R.id.faq_container).setOnClickListener(this);
        findViewById(R.id.invite_and_earn_container).setOnClickListener(this);
        findViewById(R.id.change_password_container).setOnClickListener(this);
        findViewById(R.id.help_container).setOnClickListener(this);


         drawerLayout = (DuoDrawerLayout) findViewById(R.id.drawer_layout);



        drawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
            }

            @Override
            public void onDrawerOpened(View drawerView) {
            }

            @Override
            public void onDrawerClosed(View drawerView) {
            }

            @Override
            public void onDrawerStateChanged(int newState) {
            }
        });






     /*   mCoordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator_layout);
        Toolbar toolbar= (Toolbar)findViewById(R.id.toolbar_main_activity);
        TextView tv_header = (TextView) toolbar.findViewById(R.id.txt_activty_header);
        toolbar.hideOverflowMenu();
        toolbar.showContextMenu();
        tv_header.setText(getString(R.string.app_name));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);*/

    }

    private void setBookingList() {
        String[] array={"1","2","3","4"};
        final int[] visibleview = {0};
        HomeBookingsAdapter goodsImagesAdapter=new HomeBookingsAdapter(mActivityreference,array);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(mActivityreference, LinearLayoutManager.HORIZONTAL,false);
        SnapHelper snapHelper=new PagerSnapHelper();
        snapHelper.attachToRecyclerView(recyclerViewBookings);
        recyclerViewBookings.setLayoutManager(mLayoutManager);
        recyclerViewBookings.setItemAnimator(new DefaultItemAnimator());
        recyclerViewBookings.setAdapter(goodsImagesAdapter);

        recyclerViewBookings.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                LinearLayoutManager layoutManager=LinearLayoutManager.class.cast(recyclerView.getLayoutManager());
                int position=layoutManager.findFirstCompletelyVisibleItemPosition();
                if(position==0){
                    btnStartLoading.setText(getResources().getString(R.string.txt_start_loading));
                }else {
                    btnStartLoading.setText(getResources().getString(R.string.txt_waiting_to_accept));
                }
                super.onScrolled(recyclerView, dx, dy);
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        checkInternetconnection();
        if (AppController.getInstance() != null) {
            AppController.getInstance().setConnectivityListener(this);
        }

        setDrawerData();
    }

    private void setDrawerData() {
        String fullname=User.getInstance().getFirstName()+" "+User.getInstance().getLastName();
        String email=User.getInstance().getEmail();
        ImageView imageView=(ImageView) findViewById(R.id.userimage);
        TextView username=(TextView)findViewById(R.id.user_name);
        TextView userEmail=(TextView)findViewById(R.id.user_email);
        String userImage=User.getInstance().getUserImage();
        if(username!=null&&userEmail!=null){
            username.setText(fullname);
            userEmail.setText(email);
        }
        if(CommonMethods.getInstance().validateEditFeild(userImage)){
            Ion.with(imageView)
                    .placeholder(R.drawable.driver)
                    .placeholder(R.drawable.driver)
                    .load(ConstantValues.BASE_URL+"/"+userImage);
        }
    }

    @Override
    public void onBackPressed() {
        // DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("")
                .setMessage(getResources().getString(R.string.txt_close_app))
                .setPositiveButton(getResources().getString(R.string.txt_yes), new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton(getResources().getString(R.string.txt_No), null)
                .show();

    }




    private void checkInternetconnection() {
        mIsConnected = CommonMethods.getInstance().checkInterNetConnection(mActivityreference);
        if (mIsConnected) {
            if (snackbar != null) {
                snackbar.dismiss();

            }
        } else {
            showSnackBar(getResources().getString(R.string.iconnection_availability));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationPermission = false;
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                        getUserCurrentLocation();
                    }
                   // mLocationPermission = true;

                }
                break;
          /*  case 222:
                if(grantResults.length > 0){
                    if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                        getUserCurrentLocation();
                    }
                }*/

        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    // Set UI to hide keyoard onTouch outside the edittext
    public void setUIToHideKeyBoard(View view) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    CommonMethods.getInstance().hideSoftKeyBoard(MainActivity.this);
                    return false;
                }
            });
        }

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setUIToHideKeyBoard(innerView);
            }
        }

    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {
        if (isConnected) {
            if (snackbar != null) {
                snackbar.dismiss();
            }
        } else {
            showSnackBar(getResources().getString(R.string.iconnection_availability));
        }

    }

    public void showSnackBar(String mString) {
      /*  snackbar = Snackbar
                .make(mCoordinatorLayout, mString, Snackbar.LENGTH_INDEFINITE);
        snackbar.setText(mString);
        snackbar.show();*/
    }


    private void showPopUp(int choosetraveller) {
        final Dialog openDialog = new Dialog(mActivityreference);
        openDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        openDialog.setContentView(R.layout.pick_up_dialog);
        openDialog.setTitle("Custom Dialog Box");
        openDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView travellerName = (TextView)openDialog.findViewById(R.id.txt_traveller_name_dialog);

        TextView travellerCost = (TextView)openDialog.findViewById(R.id.txt_traveller_cost);

        Button btnAgree = (Button)openDialog.findViewById(R.id.btn_agree);
        travellerName.setTypeface(mTypefaceRegular);
        travellerCost.setTypeface(mTypefaceRegular);
        btnAgree.setTypeface(mTypefaceRegular);
        if(choosetraveller==1){

        }

        btnAgree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,GoodsActivity.class);
                startActivity(intent);
                openDialog.dismiss();
            }
        });
        openDialog.show();

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if (googleMap != null) {
            this.googleMap = googleMap;
            MapStyleOptions style = MapStyleOptions.loadRawResourceStyle(
                    this, R.raw.map_style);
            this.googleMap.setMapStyle(style);
            if(mLocationPermission){
                getUserCurrentLocation();
            }else{
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        ConstantValues.PERMISSION_CURRENTLOCATION);
            }

        }


    }


    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        Location location = null;
        if (googleMap != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                location=  mLocationmanager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                outState.putParcelable(KEY_CAMERA_POSITION, googleMap.getCameraPosition());
                outState.putParcelable(ConstantValues.KEY_LOCATION, location);
                super.onSaveInstanceState(outState);
                return;
            }

        }
    }

    private void updateLocationUI() {
       if (googleMap!=null){
            if(mCurrentLocation!=null) {
                LatLngBounds AUSTRALIA = new LatLngBounds(
                        new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()), new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()));
                LatLng sydney = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude());

                CameraUpdate myLocation=CameraUpdateFactory.newLatLngZoom(AUSTRALIA.getCenter(), 18);
                googleMap.animateCamera(myLocation);
                UiSettings mUiSetting=googleMap.getUiSettings();
                mUiSetting.setTiltGesturesEnabled(true);
                mUiSetting.setRotateGesturesEnabled(true);
                MarkerOptions markerOptions=new MarkerOptions()
                        .position(sydney)
                        .title("I am here");

                CircleOptions circleOptions = new CircleOptions()
                        .center(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()))
                        .radius(3000)
                        .strokeColor(Color.BLACK)
                        .strokeWidth(3); // In meters
                Marker marker=googleMap.addMarker(markerOptions);
                //googleMap.addCircle(circleOptions);
               // animateMarker(marker);

            }
       }
    }


    @Override
    public void onClick(View view) {
        int id=view.getId();
        switch (id){
            case R.id.navigation_menu:
                if(drawerLayout.isDrawerOpen(Gravity.RIGHT)){
                    drawerLayout.closeDrawer(Gravity.RIGHT);
                }else {
                    drawerLayout.openDrawer(Gravity.RIGHT);
                }
                break;
            case R.id.menu_delivery:
              Intent intent=new Intent(this,DeliveryActivity.class);
              startActivity(intent);
                break;
            case R.id.menu_setting:
                Intent setting=new Intent(this,SettingActivity.class);
                startActivity(setting);
                break;
            case R.id.userimage:
                Intent edit=new Intent(this,EditProfileActivity.class);
                startActivity(edit);
                break;
            case R.id.revenue_container:
                Intent revenue=new Intent(this,RevenueActivity.class);
                startActivity(revenue);
                break;
            case R.id.contactus_container:
                Intent cms=new Intent(this,CMSActivity.class);
                cms.putExtra(ConstantValues.CHOOSE_PAGE,1);
                startActivity(cms);
                break;
            case R.id.aboutus_container:
                Intent cms1=new Intent(this,CMSActivity.class);
                cms1.putExtra(ConstantValues.CHOOSE_PAGE,3);
                startActivity(cms1);
                break;
            case R.id.privacy_container:
                Intent cms3=new Intent(this,CMSActivity.class);
                cms3.putExtra(ConstantValues.CHOOSE_PAGE,2);
                startActivity(cms3);
                break;
            case R.id.faq_container:
                Intent cms4=new Intent(this,CMSActivity.class);
                cms4.putExtra(ConstantValues.CHOOSE_PAGE,4);
                startActivity(cms4);
                break;
            case R.id.invite_and_earn_container:
                Intent cms5=new Intent(this,CMSActivity.class);
                cms5.putExtra(ConstantValues.CHOOSE_PAGE,5);
                startActivity(cms5);
                break;
            case R.id.change_password_container:
                Intent cms6=new Intent(this,CMSActivity.class);
                cms6.putExtra(ConstantValues.CHOOSE_PAGE,6);
                startActivity(cms6);
                break;
            case R.id.help_container:
                Intent cms7=new Intent(this,CMSActivity.class);
                cms7.putExtra(ConstantValues.CHOOSE_PAGE,7);
                startActivity(cms7);
                break;
            case R.id.btn_start_loading:
                break;
            case R.id.box_container:
            case R.id.bookingtxt_container:
                showPopUp(1);
                break;
        }

    }
}
