package com.app.driver.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.app.driver.R;
import com.app.driver.adapter.BookingsAdapter;


public class OnGoingFragment extends Fragment {
    private ListView listView;
    private Activity activity;
    private String[] array={"Single Bed","Refrigerator","Single Bed"};

    //TextView textView;


    public OnGoingFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.ongoing_deliveries, container, false);
        listView=(ListView)view.findViewById(R.id.delivery_history);
        listView.setAdapter(new BookingsAdapter(activity,array,0));
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);


    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity=activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }



}
